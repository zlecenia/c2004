export { ConnectManagerView } from './connect-manager.view';
export { ConnectManagerService } from './connect-manager.service';
export type { Activity, Scenario, TestTypeAssignment } from './connect-manager.service';
