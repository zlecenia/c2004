export { PermissionsPage } from './permissions.page';
export type { PermissionsData, PermissionRole } from './permissions.page';
