export { SecuritySettingsPage } from './security-settings.page';
export type { SecuritySettingsData } from './security-settings.page';
