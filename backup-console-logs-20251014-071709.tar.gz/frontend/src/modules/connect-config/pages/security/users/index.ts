// frontend/src/modules/connect-config/pages/security/users/index.ts

export { UsersPage } from './users.page';
export type { User, UsersData } from './users.page';
