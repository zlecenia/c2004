export { NetworkPage } from './network.page';
export type { NetworkData } from './network.page';
