// frontend/src/modules/connect-config/pages/system/index.ts

// Export all system pages
export * from './system';
export * from './network';
