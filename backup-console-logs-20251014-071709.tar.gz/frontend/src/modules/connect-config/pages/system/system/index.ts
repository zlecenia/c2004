// frontend/src/modules/connect-config/pages/system/system/index.ts

export { SystemPage } from './system.page';
export type { SystemData } from './system.page';
