export { StoragePage } from './storage.page';
export type { StorageData } from './storage.page';
