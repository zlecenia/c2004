// frontend/src/modules/connect-config/pages/devices/rfid-config/index.ts

export { RfidConfigPage } from './rfid-config.page';
export type { RfidConfigData } from './rfid-config.page';
