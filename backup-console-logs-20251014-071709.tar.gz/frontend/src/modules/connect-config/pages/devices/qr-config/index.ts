// frontend/src/modules/connect-config/pages/devices/qr-config/index.ts

export { QrConfigPage } from './qr-config.page';
export type { QrConfigData } from './qr-config.page';
