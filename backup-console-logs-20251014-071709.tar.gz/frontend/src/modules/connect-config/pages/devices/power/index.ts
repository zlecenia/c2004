export { PowerPage } from './power.page';
export type { PowerData } from './power.page';
