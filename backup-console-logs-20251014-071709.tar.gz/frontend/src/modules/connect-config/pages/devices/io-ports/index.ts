// frontend/src/modules/connect-config/pages/devices/io-ports/index.ts

export { IoPortsPage } from './io-ports.page';
export type { IoPortsData } from './io-ports.page';
