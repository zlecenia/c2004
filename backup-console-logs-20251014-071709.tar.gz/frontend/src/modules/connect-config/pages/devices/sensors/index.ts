// frontend/src/modules/connect-config/pages/devices/sensors/index.ts

export { SensorsPage } from './sensors.page';
export type { SensorsData } from './sensors.page';
