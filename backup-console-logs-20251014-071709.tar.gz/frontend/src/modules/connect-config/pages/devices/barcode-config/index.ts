// frontend/src/modules/connect-config/pages/devices/barcode-config/index.ts

export { BarcodeConfigPage } from './barcode-config.page';
export type { BarcodeConfigData } from './barcode-config.page';
